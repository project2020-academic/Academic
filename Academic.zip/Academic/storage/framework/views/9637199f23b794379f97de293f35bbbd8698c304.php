<?php
//import Auth;
?>
<div class="sidebar" data-color="orange" data-background-color="white" data-image="https://material-dashboard-laravel.creative-tim.com/material/img/sidebar-1.jpg">
                <div class="logo">
                    <a href="#" class="simple-text logo-normal">
                    <!-- <img src="../images/logo.png" width="20px"> -->
                    UCEK (A)
                    </a>
                </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                <li class="nav-item active">
                    <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/home">
                    <i class="material-icons">dashboard</i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <?php 
                //$role = Auth::user->role();
                // if($role == 'admin')
                // {
                ?> 
                <li class="nav-item ">
                    <a class="nav-link" data-toggle="collapse" href="#regulationsmaster" aria-expanded="true">
                    <i class="material-icons">class</i>
                    <p>Regulations Master
                        <b class="caret"></b>
                    </p>
                    </a>
                    <div class="collapse show" id="regulationsmaster">
                    <ul class="nav">
                        <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span class="sidebar-mini"> AR  </span>
                            <span class="sidebar-normal">ADD REGULATION </span>
                        </a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/user">
                            <span class="sidebar-mini"> RM </span>
                            <span class="sidebar-normal"> REGULATION MANAGEMENT </span>
                        </a>
                        </li>
                    </ul>
                    </div>
                </li>
                <?php //} ?>
                <li class="nav-item ">
                    <a class="nav-link" data-toggle="collapse" href="#degreemaster" aria-expanded="true">
                    <i class="material-icons">school</i>
                    <p>Degree Master
                        <b class="caret"></b>
                    </p>
                    </a>
                    <div class="collapse show" id="degreemaster">
                    <ul class="nav">
                        <li class="nav-item">
                        <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/profile">
                            <span class="sidebar-mini"> ADM </span>
                            <span class="sidebar-normal">ADD DEGREE MASTER</span>
                        </a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/user">
                            <span class="sidebar-mini"> VDM </span>
                            <span class="sidebar-normal"> DEGREE MASTER </span>
                        </a>
                        </li>
                    </ul>
                    </div>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" data-toggle="collapse" href="#addDepartment" aria-expanded="true">
                    <i class="material-icons">account_balance</i>
                   <p>Department Master
                        <b class="caret"></b>
                    </p>
                    </a>
                    <div class="collapse show" id="addDepartment">
                    <ul class="nav">
                        <li class="nav-item">
                        <a class="nav-link" href="#">
                            <span class="sidebar-mini"> AD</span>
                            <span class="sidebar-normal">ADD DEPARTMENT </span>
                        </a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/user">
                            <span class="sidebar-mini"> VD </span>
                            <span class="sidebar-normal"> VIEW DEPARTMENTS </span>
                        </a>
                        </li>
                    </ul>
                    </div>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" data-toggle="collapse" href="#coursemaster" aria-expanded="true">
                    <i class="material-icons">chrome_reader_mode</i>
                    <p>Course Master
                        <b class="caret"></b>
                    </p>
                    </a>
                    <div class="collapse show" id="coursemaster">
                    <ul class="nav">
                        <li class="nav-item">
                        <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/profile">
                            <span class="sidebar-mini"> AC</span>
                            <span class="sidebar-normal">ADD COURSE</span>
                        </a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/user">
                            <span class="sidebar-mini"> VC   </span>
                            <span class="sidebar-normal"> VIEW COURSES </span>
                        </a>
                        </li>
                    </ul>
                    </div>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" data-toggle="collapse" href="#studentmaster" aria-expanded="true">
                    <i class="material-icons">perm_identity</i>
                    <p>Student Master
                        <b class="caret"></b>
                    </p>
                    </a>
                    <div class="collapse show" id="studentmaster">
                    <ul class="nav">
                        <li class="nav-item">
                        <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/profile">
                            <span class="sidebar-mini"> AS</span>
                            <span class="sidebar-normal">ADD STUDENT</span>
                        </a>
                        </li>
                        <li class="nav-item">
                        <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/user">
                            <span class="sidebar-mini"> VS  </span>
                            <span class="sidebar-normal"> VIEW STUDENT </span>
                        </a>
                        </li>
                    </ul>
                    </div>
                </li>
                <!-- <li class="nav-item">
                    <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/table-list">
                    <i class="material-icons">content_paste</i>
                        <p>Table List</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/typography">
                    <i class="material-icons">library_books</i>
                        <p>Typography</p>
                    </a>
                </li> -->
                <!-- <li class="nav-item">
                    <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/icons">
                    <i class="material-icons">bubble_chart</i>
                    <p>Icons</p>
                    </a>
                </li> -->
             <!--   <li class="nav-item">
                    <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/map">
                    <i class="material-icons">location_ons</i>
                        <p>Maps</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/notifications">
                    <i class="material-icons">notifications</i>
                    <p>Notifications</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/rtl-support">
                    <i class="material-icons">language</i>
                    <p>RTL Support</p>
                    </a>
                </li>
                <li class="nav-item active-pro">
                    <a class="nav-link" href="https://material-dashboard-laravel.creative-tim.com/upgrade">
                    <i class="material-icons">unarchive</i>
                    <p>Upgrade to PRO</p>
                    </a>
                </li> -->
                </ul>
            </div>
        <?php /**PATH C:\xampp\htdocs\myproj\resources\views/subpages/sidebarwrapper.blade.php ENDPATH**/ ?>