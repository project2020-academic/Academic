<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});
Route::get('addDepartment', function () {
    return view('departments.addDepartment');
});

Route::get('addRegulation', function () {
    return view('regulations.addRegulation');
});

Route::get('addDegree', function () {
    return view('degrees.addDegree');
});

Route::get('addCourse', function () {
    return view('courses.addCourse');
});


Route::post('addRegulation','RegulationController@insert');

Route::post('addCourse','CourseController@insert');

Route::post('addDepartment','DepartmentController@insert');

Route::post('addDegree','DegreeController@insert');